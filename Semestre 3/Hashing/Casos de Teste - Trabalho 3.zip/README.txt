Arquivo zip gerado em: 16/06/2024 14:31:43 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Trabalho 3